"""Explicit local model installation and device readiness for end users."""
import hashlib
import json
import os
from pathlib import Path
import threading
import time
import urllib.request
from .core import now, sync_dir

ASR_MODELS = {
    'medium': {'label': 'Whisper medium', 'description': 'Qualitätsorientierter Einstieg · mehrsprachig', 'bytes': 1600000000, 'license': 'MIT (OpenAI Whisper)'},
    'large-v3-turbo': {'label': 'Whisper large-v3-turbo', 'description': 'Großes Sprachmodell mit verkürztem Decoder · mit medium vergleichen', 'bytes': 1700000000, 'license': 'MIT (OpenAI Whisper)'},
    'large-v3': {'label': 'Whisper large-v3', 'description': 'Umfangreichster Kandidat · Qualität vor Geschwindigkeit', 'bytes': 3200000000, 'license': 'MIT (OpenAI Whisper)'},
}
LLM_MODELS = {
    'qwen3:4b-instruct': {'label': 'Qwen3 4B Instruct', 'description': 'Empfohlener Pi-8-GB-Einstieg · direkte Protokolle ohne Denkphase · ca. 2,5 GB', 'bytes': 2800000000, 'license': 'Apache 2.0'},
    'qwen3:8b': {'label': 'Qwen3 8B', 'description': 'Qualitätsorientierter Kandidat · ca. 5,2 GB Download', 'bytes': 5500000000, 'license': 'Apache 2.0'},
    'qwen3:4b': {'label': 'Qwen3 4B Thinking', 'description': 'Denkmodell zum Vergleich · längere Laufzeit · ca. 2,5 GB Download', 'bytes': 2800000000, 'license': 'Apache 2.0'},
    'gemma3:4b': {'label': 'Gemma 3 4B', 'description': 'Alternative Familie · ca. 3,4 GB Download', 'bytes': 3700000000, 'license': 'Gemma-Nutzungsbedingungen (keine OSI-Open-Source-Lizenz)'},
}


def local_json(path, timeout=3):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open('http://127.0.0.1:11434' + path, timeout=timeout) as response:
        return json.load(response)


class ModelManager:
    def __init__(self, store):
        self.store = store
        self.models = store.root / 'models'
        self.models.mkdir(mode=0o700, exist_ok=True)
        self.stopping = threading.Event()
        self.lock = threading.Lock()
        self.thread = None
        with store.db() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS installations (
              id INTEGER PRIMARY KEY CHECK(id=1), backend TEXT, model TEXT, state TEXT,
              message TEXT, completed INTEGER, total INTEGER, updated REAL)''')
            db.execute("UPDATE installations SET state='failed', message='Download durch Neustart unterbrochen. Bitte erneut installieren.', updated=? WHERE state='running'", (now(),))

    def status(self):
        with self.store.db() as db:
            row = db.execute('SELECT * FROM installations WHERE id=1').fetchone()
        return dict(row) if row else {'state': 'idle', 'completed': 0, 'total': 0, 'message': ''}

    def catalog(self):
        c = self.store.config()
        try:
            tags = local_json('/api/tags')
            installed = {m['name'] for m in tags.get('models', [])}
            ollama = True
        except (OSError, ValueError):
            installed, ollama = set(), False
        asr = []
        for key, model in ASR_MODELS.items():
            path = self.models / f'ggml-{key}.bin'
            asr.append(model | {'id': key, 'path': str(path), 'installed': path.is_file()})
        # Preserve manually configured local models without inventing readiness.
        if c['whisper_model'] not in [m['path'] for m in asr]:
            path = Path(c['whisper_model'])
            asr.append({'id': 'custom', 'label': 'Eigenes lokales Whisper-Modell', 'description': path.name,
                        'path': str(path), 'installed': path.is_file(), 'bytes': 0, 'license': 'Selbst prüfen'})
        llm = [m | {'id': key, 'installed': key in installed} for key, m in LLM_MODELS.items()]
        for key in sorted(installed - set(LLM_MODELS)):
            if 'cloud' not in key.lower():
                llm.append({'id': key, 'label': key, 'description': 'Bereits lokal vorhanden',
                            'installed': True, 'bytes': 0, 'license': 'Modellabhängig'})
        return {'asr': asr, 'llm': llm, 'ollama': ollama,
                'whisper_runtime': Path(c['whisper_binary']).is_file() and os.access(c['whisper_binary'], os.X_OK),
                'selected_asr': c['whisper_model'], 'selected_llm': c['summary_model'], 'download': self.status()}

    def update(self, **fields):
        fields['updated'] = now()
        with self.store.db() as db:
            db.execute('UPDATE installations SET '+','.join(f'{k}=?' for k in fields)+' WHERE id=1', tuple(fields.values()))

    def install(self, backend, model):
        candidates = ASR_MODELS if backend == 'whisper' else LLM_MODELS if backend == 'ollama' else {}
        if model not in candidates:
            raise ValueError('Dieses Modell gehört nicht zur erlaubten lokalen Auswahl.')
        with self.lock:
            if self.thread and self.thread.is_alive():
                raise ValueError('Es läuft bereits ein Modelldownload.')
            size = candidates[model]['bytes']
            # Reserve space for ongoing recording finalization and downloads.
            required = size + 2 * 1024**3
            if self.store.free_mb() * 1024**2 < required:
                raise ValueError(f'Für dieses Modell werden mindestens {required/1024**3:.1f} GiB freier Speicher inklusive Reserve benötigt.')
            if backend == 'ollama':
                try:
                    local_json('/api/tags')
                except (OSError, ValueError) as e:
                    raise ValueError('Der lokale Modelldienst fehlt. Einmalige Basissysteminstallation abschließen.') from e
            with self.store.db() as db:
                db.execute('INSERT OR REPLACE INTO installations VALUES(1,?,?,?,?,?,?,?)',
                           (backend, model, 'running', 'Download wird vorbereitet …', 0, size, now()))
            self.thread = threading.Thread(target=self.run, args=(backend, model), daemon=True)
            self.thread.start()
        return self.status()

    def progress(self, message, completed=0, total=0, force=False):
        # Durable progress at most once every two seconds: avoid constant SD fsyncs.
        if force or time.monotonic() - self.last_update >= 2:
            self.update(message=message[:300], completed=completed, total=total)
            self.last_update = time.monotonic()

    def run(self, backend, model):
        self.last_update = 0
        try:
            if backend == 'whisper':
                self.download_whisper(model)
            else:
                self.download_ollama(model)
            if self.stopping.is_set():
                raise RuntimeError('Download unterbrochen. Bitte erneut installieren.')
            self.update(state='completed', message='Modell vollständig installiert.')
        except Exception as e:
            self.update(state='failed', message=str(e)[:400])

    def download_whisper(self, model):
        destination = self.models / f'ggml-{model}.bin'
        if destination.exists():
            self.progress('Modell bereits vorhanden.', destination.stat().st_size, destination.stat().st_size, True)
            return
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        # Get the official repository's LFS SHA-256 before downloading weights.
        with opener.open('https://huggingface.co/api/models/ggerganov/whisper.cpp?blobs=true', timeout=30) as response:
            metadata = json.load(response)
        filename = destination.name
        info = next((f for f in metadata.get('siblings', []) if f.get('rfilename') == filename), None)
        expected = (info or {}).get('lfs', {}).get('sha256')
        if not expected:
            raise RuntimeError('Prüfsumme des Modells konnte nicht bestätigt werden. Später erneut versuchen.')
        url = f'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/{filename}'
        partial = destination.with_suffix('.bin.download')
        digest, completed = hashlib.sha256(), 0
        try:
            with opener.open(url, timeout=60) as source, open(partial, 'wb') as target:
                total = int(source.headers.get('Content-Length', (info or {}).get('size', 0)))
                if total and self.store.free_mb() * 1024**2 < total + 2*1024**3:
                    raise RuntimeError('Zu wenig Speicher für den tatsächlichen Modelldownload.')
                while True:
                    if self.stopping.is_set():
                        raise RuntimeError('Download unterbrochen. Bitte erneut installieren.')
                    block = source.read(1024 * 1024)
                    if not block:
                        break
                    if self.store.free_mb() < 1024:
                        raise RuntimeError('Speicherreserve erreicht. Download sicher abgebrochen.')
                    target.write(block)
                    digest.update(block)
                    completed += len(block)
                    if completed > ASR_MODELS[model]['bytes'] * 2:
                        raise RuntimeError('Unerwartete Modellgröße. Download abgebrochen.')
                    self.progress('Whisper-Modell wird heruntergeladen', completed, total)
                target.flush()
                os.fsync(target.fileno())
            if digest.hexdigest() != expected:
                raise RuntimeError('Modell-Prüfsumme stimmt nicht. Download bitte wiederholen.')
            os.replace(partial, destination)
            sync_dir(destination.parent)
            self.progress('Prüfsumme bestätigt.', completed, completed, True)
        finally:
            partial.unlink(missing_ok=True)

    def download_ollama(self, model):
        request = urllib.request.Request('http://127.0.0.1:11434/api/pull',
                    data=json.dumps({'model': model, 'stream': True}).encode(),
                    headers={'Content-Type': 'application/json'})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        success = False
        with opener.open(request, timeout=60) as response:
            for line in response:
                if self.stopping.is_set():
                    raise RuntimeError('Download unterbrochen. Bitte erneut installieren.')
                if not line.strip():
                    continue
                item = json.loads(line)
                if item.get('error'):
                    raise RuntimeError('Lokaler Modelldownload fehlgeschlagen: ' + str(item['error'])[:200])
                if self.store.free_mb() < 1024:
                    raise RuntimeError('Speicherreserve erreicht. Modelldownload abgebrochen.')
                self.progress('Ollama: ' + item.get('status', 'Download'), item.get('completed', 0), item.get('total', 0))
                if item.get('status') == 'success':
                    success = True
        if not success:
            raise RuntimeError('Modelldienst hat keinen erfolgreichen Abschluss bestätigt.')
        self.progress('Modell installiert.', 1, 1, True)

    def close(self):
        self.stopping.set()
