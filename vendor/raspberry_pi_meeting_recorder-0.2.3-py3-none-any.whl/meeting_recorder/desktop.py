"""Headless shared engine for native Qt clients and the existing web product.

No Qt dependency. Own data directory/lock. No HTTP server or cloud adapter.
Clients retain their own session IDs and persist the returned job ID.
"""
import fcntl
import json
import os
from pathlib import Path
import subprocess
import threading
import time
from .child_process import owned_command
from .core import Store, atomic_write
from .audio import Recorder, devices
from .probe import MicrophoneTest
from .processing import Worker
from .setup import ModelManager


class DesktopEngine:
    def __init__(self, root, command_factory=None, backend=None):
        self.store = Store(root)
        self.lockfile = open(self.store.root/'service.lock', 'a')
        try:
            fcntl.flock(self.lockfile, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.lockfile.close()
            raise RuntimeError('Diese lokale Datenablage wird bereits verwendet.')
        self.worker = Worker(self.store, backend)
        self.recorder = Recorder(self.store, command_factory)
        self.models = ModelManager(self.store)
        self.probe = MicrophoneTest(self.recorder)
        # 8 GiB native product defaults; persisted selections always win.
        with self.store.db() as db:
            first = db.execute('SELECT 1 FROM settings').fetchone() is None
        if first:
            self.store.save_config({'summary_model': 'qwen3:4b-instruct'})
        # An import may have crashed after its durable source snapshot but before
        # the importing state commit. Do not treat that job as microphone PCM.
        for job in self.store.list():
            if job['state']=='recording' and (self.store.folder(job['id'])/'source.json').exists():
                self.store.update(job['id'],state='importing')
        self.recorder.recover()
        self.store.recover_processing()
        self.threads = []
        self.imports = set()
        self.import_lock = threading.Lock()
        self.closing = False
        for job in self.store.list():
            if job['state'] == 'importing':
                self._launch_import(job['id'])
        self._thread(self.worker.run)
        self._thread(self.recorder.monitor)

    def _thread(self, target, *args):
        t = threading.Thread(target=target, args=args, daemon=True)
        self.threads.append(t)
        t.start()
        return t

    def configure(self, changes):
        if self.recorder.active or self.recorder.probe:
            raise ValueError('Bitte Aufnahme oder Mikrofontest zuerst beenden.')
        return self.store.save_config(changes)

    def start(self, title):
        if self.closing:
            raise RuntimeError('Anwendung wird beendet.')
        ident = self.recorder.start(title)
        c = self.store.config()
        atomic_write(self.store.folder(ident)/'request.json', json.dumps({
            'summary_model': c['summary_model'], 'whisper_model': c['whisper_model'], 'context_size': 4096}))
        return ident

    def stop(self):
        return self.recorder.stop()

    def enqueue(self, source, title, transcript=None, prompt=''):
        """Return durable job ID; stream conversion happens outside UI thread."""
        if self.closing:
            raise RuntimeError('Anwendung wird beendet.')
        source = Path(source).resolve()
        if not source.is_file():
            raise ValueError('Audiodatei fehlt.')
        ident = self.store.create(title)
        folder = self.store.folder(ident)
        atomic_write(folder/'source.json', json.dumps({'path': str(source)}))
        c = self.store.config()
        atomic_write(folder/'request.json', json.dumps({'prompt': prompt, 'summary_model': c['summary_model'],
                     'whisper_model': c['whisper_model'], 'context_size': 4096}))
        if transcript and transcript.strip():
            atomic_write(folder/'transcript.txt', transcript)
        self.store.update(ident, state='importing')
        self._launch_import(ident)
        return ident

    def _launch_import(self, ident):
        with self.import_lock:
            if ident in self.imports:
                return
            self.imports.add(ident)
        self._thread(self._import, ident)

    def _import(self, ident):
        folder = self.store.folder(ident)
        proc = None
        try:
            source = json.loads((folder/'source.json').read_text())['path']
            # Worst case reserve; actual ffmpeg output additionally monitored.
            if self.store.free_mb() < self.store.config()['min_free_mb'] + 128:
                raise RuntimeError('Zu wenig freier Speicher zum Vorbereiten der Aufnahme.')
            tmp = folder/'audio.import.wav'
            with open(folder/'conversion.log', 'ab') as log:
                proc = subprocess.Popen(owned_command(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', source,
                       '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', str(tmp)]), stdout=log, stderr=log)
                while proc.poll() is None:
                    if self.worker.stopping.wait(.2):
                        raise RuntimeError('Vorbereitung unterbrochen; wird beim nächsten Start fortgesetzt.')
                    if self.store.free_mb() < 256:
                        raise RuntimeError('Speicherreserve erreicht; Vorbereitung abgebrochen.')
                if proc.returncode:
                    raise RuntimeError('Audio konnte nicht vorbereitet werden. conversion.log prüfen.')
            with open(tmp, 'rb') as f:
                os.fsync(f.fileno())
            os.replace(tmp, folder/'audio.wav')
            self.store.update(ident, state='queued')
        except Exception as e:
            if not self.worker.stopping.is_set():
                self.store.update(ident, state='failed', error=str(e)[:500])
        finally:
            if proc and proc.poll() is None:
                proc.terminate()
                try: proc.wait(timeout=3)
                except subprocess.TimeoutExpired: proc.kill(); proc.wait()
            with self.import_lock:
                self.imports.discard(ident)

    def retry(self, ident):
        folder = self.store.folder(ident)
        if not (folder/'audio.wav').exists() and (folder/'source.json').exists():
            if self.store.get(ident)['state'] != 'failed':
                raise ValueError('Nur fehlgeschlagene Aufgaben wiederholen.')
            self.store.update(ident, state='importing', error='')
            self._launch_import(ident)
        else:
            self.store.retry(ident)

    def state(self):
        return {'jobs': self.store.list(), 'recording': self.recorder.status(),
                'free_mb': self.store.free_mb(), 'config': self.store.config(),
                'progress': self.worker.progress, 'installation': self.models.status(),
                'microphone_test': self.probe.status()}

    def result(self, ident):
        folder = self.store.folder(ident)
        return {key: (folder/name).read_text() if (folder/name).exists() else ''
                for key, name in [('transcript', 'transcript.txt'), ('summary', 'summary.md')]}

    def close(self):
        if self.recorder.active:
            raise RuntimeError('Aufnahme zuerst sicher beenden.')
        self.closing = True
        self.worker.stopping.set()
        self.models.close()
        self.probe.close()
        self.recorder.closed.set()
        for t in self.threads:
            t.join(timeout=6)
        auxiliary=[t for t in (self.models.thread,self.probe.thread) if t]
        for t in auxiliary:t.join(timeout=2)
        # Keep the exclusive lock while an inference/download/probe is still alive.
        if not any(t.is_alive() for t in self.threads+auxiliary):
            self.lockfile.close()
