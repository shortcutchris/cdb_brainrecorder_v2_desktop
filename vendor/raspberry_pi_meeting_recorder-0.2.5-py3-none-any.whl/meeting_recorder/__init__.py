"""Local Raspberry Pi meeting recorder."""
__version__ = '0.1.0'
