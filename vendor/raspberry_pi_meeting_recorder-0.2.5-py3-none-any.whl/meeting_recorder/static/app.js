'use strict';
const $ = id => document.getElementById(id);
let token = sessionStorage.getItem('meeting-token') || '';
let state = null, csrf = '', selected = null, busy = false, detailSignature = '', screen = 'record';
let setupData=null, setupTab='audio', setupOpened=false, lastDownloadState='', lastProbeState='', audioURL=null;
const labels = {recording:'Aufnahme läuft',queued:'Wartet',transcribing:'Transkription',summarizing:'Zusammenfassung',completed:'Fertig',failed:'Fehler',deleting:'Wird gelöscht'};
function notice(message) { $('notice').textContent = message; $('notice').hidden = !message; }
async function api(path, method = 'GET', body) {
  const headers = {Authorization: token ? `Bearer ${token}` : ''};
  if (method === 'POST') { headers['X-CSRF-Token'] = csrf; headers['Content-Type'] = 'application/json'; }
  const response = await fetch(path, {method, headers, body: body === undefined ? undefined : JSON.stringify(body)});
  if (response.status === 401) { $('login').hidden = false; throw new Error('Bitte mit dem Gerätetoken anmelden.'); }
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Anfrage fehlgeschlagen.');
  $('login').hidden = true;
  return result;
}
function formatDuration(n) { n = Math.max(0, Math.floor(n || 0)); return `${Math.floor(n/3600).toString().padStart(2,'0')}:${Math.floor(n/60%60).toString().padStart(2,'0')}:${(n%60).toString().padStart(2,'0')}`; }
function date(n) { return new Date(n * 1000).toLocaleString('de-DE', {dateStyle:'medium',timeStyle:'short'}); }
function button(text, fn, cls='quiet') { const b = document.createElement('button'); b.type='button'; b.className=cls; b.textContent=text; b.onclick=fn; return b; }
async function action(fn) { if (busy) return; busy=true; try { await fn(); notice(''); await refresh(); } catch(e) { notice(e.message); } finally {busy=false;} }
function render() {
  const recording = state.recording.id;
  $('demo-banner').hidden = !state.demo;
  document.body.classList.toggle('demo', !!state.demo);
  $('disk').classList.toggle('low-space', state.free_mb < state.config.min_free_mb);
  $('storage-info').textContent = `Datenpfad: ${state.demo ? "Demoverzeichnis (nur Vorschau)" : state.data_dir}. ${(state.free_mb/1024).toFixed(1)} GiB frei; Reserve vor Start: ${state.config.min_free_mb} MiB. Format: 16 kHz, Mono, 16 Bit · 115,2 MB pro Stunde. Beim Abschluss vorübergehend etwa doppelter Audioplatz.`;
  document.body.classList.toggle('recording', !!recording);
  $('record-label').textContent = recording ? (state.demo ? 'DEMO · AUFNAHME SIMULIERT' : 'AUFNAHME LÄUFT AM PI') : 'BEREIT FÜR DAS NÄCHSTE MEETING';
  $('timer').textContent = recording ? formatDuration((Date.now()/1000)-state.recording.started) : 'Neue Aufnahme';
  const recordLabel=recording ? 'Aufnahme beenden' : 'Aufnahme starten';
  $('record-button-label').textContent=recordLabel;
  $('record-button').setAttribute('aria-label',recordLabel);
  $('record-icon').src=recording ? '/icons/square.svg' : '/icons/mic.svg';
  $('title').disabled = !!recording;
  if(recording) $('title').value=state.jobs.find(j=>j.id===recording)?.title||'';
  $('record-description').textContent=state.demo ? 'Demovorschau: Es wird kein Mikrofon verwendet. Aufnahme und Verarbeitung sind simuliert.' : 'Das Mikrofon am Raspberry Pi nimmt auf. Bitte informiere alle Teilnehmenden vor dem Start.';
  $('disk').textContent = `${(state.free_mb/1024).toFixed(1)} GiB frei auf dem Gerät${state.free_mb < state.config.min_free_mb ? ' · Zu wenig Speicher für neue Aufnahme' : ''}`;
  const queued = state.jobs.filter(j=>j.state==='queued').length;
  const active = state.jobs.find(j=>['transcribing','summarizing'].includes(j.state));
  $('queue').textContent = `Warteschlange · ${queued}${active ? ' + 1 in Arbeit' : ''}`;
  $('global-record').textContent=recording ? `● Aufnahme · ${formatDuration(Date.now()/1000-state.recording.started)}` : 'Mikrofon bereit';
  $('global-record').classList.toggle('live', !!recording);
  $('global-process').textContent=active ? `${labels[active.state]} läuft` : `${queued} Meeting${queued===1?'':'s'} warten`;
  $('home-process-title').textContent=active ? active.title : (queued ? `${queued} Meeting${queued===1?'':'s'} in der Warteschlange` : 'Keine offenen Meetings');
  $('home-process-detail').textContent=active ? `${labels[active.state]} · ${state.progress || 'lokal auf diesem Gerät'} · ${queued} weitere warten` : 'Du kannst jederzeit eine neue Aufnahme starten.';
  $('worker-progress').textContent = active ? `${labels[active.state]}: ${active.title}${state.progress ? ' · '+state.progress : ''}` : 'Bereit. Neue Meetings werden automatisch verarbeitet.';
  const list = $('meetings'); list.replaceChildren();
  if (!state.jobs.length) { const empty = document.createElement('div'); empty.className='empty panel'; empty.textContent='Noch keine Meetings. Starte deine erste Aufnahme.'; list.append(empty); }
  for (const job of state.jobs) {
    const row=document.createElement('article'); row.className='meeting';
    const info=document.createElement('div'); info.className='meeting-info';
    const title=document.createElement('strong'); title.textContent=job.title;
    const meta=document.createElement('small'); meta.textContent=`${date(job.created)} · ${formatDuration(job.duration)}${job.interrupted ? ' · Aufnahme unterbrochen – Audio prüfen' : ''}`;
    info.append(title,meta);
    const badge=document.createElement('span'); badge.className=`badge ${job.state}`; badge.textContent=labels[job.state]||job.state;
    row.append(info,badge,button('Öffnen',()=>openDetail(job.id))); list.append(row);
  }
  renderSetupStatus();
  if (!$('settings-form').contains(document.activeElement)) for (const [key,value] of Object.entries(state.config)) { const input=$('settings-form').elements.namedItem(key); if(input) input.value=value; }
}
async function refresh() {
  try { state = await api('/api/state'); csrf = state.csrf; render();
    if(state.needs_setup && !state.demo && !setupOpened) {setupOpened=true;showScreen('settings');}
    if(selected && $('detail').open) {
      const job=state.jobs.find(j=>j.id===selected);
      const signature=job ? `${job.id}:${job.updated}:${job.state}` : '';
      if (!job) { $('detail').close(); selected=null; }
      else if(signature!==detailSignature) await loadDetail(selected);
    }
  } catch(e) { notice(e.message || 'Gerät nicht erreichbar.'); }
}
function renderMarkdown(element, text) {
  element.replaceChildren();
  for(const line of text.split('\n')) {
    if(!line.trim()) continue;
    let tag='p', content=line;
    const heading=line.match(/^#{1,6}\s+(.+)$/);
    if(heading) {tag='h4';content=heading[1];}
    else if(/^[-*•]\s/.test(line)) content='• '+line.replace(/^[-*•]\s+/, '');
    const node=document.createElement(tag); node.textContent=content; element.append(node);
  }
}
async function loadDetail(id) {
  const job=await api(`/api/meetings/${id}`);
  detailSignature=`${job.id}:${job.updated}:${job.state}`;
  $('detail-title').textContent=(state.demo?'Demo · ':'')+job.title;
  $('detail-meta').textContent=`${date(job.created)} · ${formatDuration(job.duration)} · ${labels[job.state]} · Versuche: ${job.attempts}`;
  $('detail-error').textContent=job.error || (job.interrupted ? 'Diese Aufnahme wurde unterbrochen oder automatisch beendet. Bitte Audio prüfen.' : '');
  $('detail-error').hidden=!$('detail-error').textContent;
  renderMarkdown($('summary'), job.summary||'Die Zusammenfassung erscheint nach der lokalen Verarbeitung.');
  $('transcript').textContent=job.transcript||'Das Transkript ist noch nicht verfügbar.';
  $('metrics').textContent=JSON.stringify(JSON.parse(job.metrics),null,2);
  const exports=$('exports'); exports.replaceChildren();
  for (const [kind,label] of [['export','Protokoll (.md)'],['audio','Audio (.wav)'],['transcript','Transkript (.txt)'],['summary','Zusammenfassung (.md)'],['metrics','Messwerte (.json)']]) {
    if ((kind==='audio'&&state.demo)||(kind==='transcript'&&!job.transcript)||(kind==='summary'&&!job.summary)||(kind==='audio'&&job.state==='recording')) continue;
    exports.append(button(label,()=>download(id,kind)));
  }
  if(job.state==='failed') exports.append(button('Erneut versuchen',()=>action(async()=>{await api(`/api/meetings/${id}/retry`,'POST',{}); await loadDetail(id);})));
  if(!['recording','transcribing','summarizing'].includes(job.state)) exports.append(button('Meeting löschen',()=>{
    if(confirm('Aufnahme, Transkript und Zusammenfassung endgültig von diesem Gerät löschen?')) action(async()=>{await api(`/api/meetings/${id}/delete`,'POST',{}); $('detail').close(); selected=null;});
  },'danger'));
}
async function openDetail(id) { try {showDetailTab('summary'); selected=id; await loadDetail(id); if(!$('detail').open) $('detail').showModal();} catch(e){notice(e.message);} }
async function download(id, kind) {
  try {
    const response=await fetch(`/api/meetings/${id}/${kind}`,{headers:{Authorization:token?`Bearer ${token}`:''}});
    if(!response.ok) { const err=await response.json(); throw new Error(err.error); }
    const url=URL.createObjectURL(await response.blob()); const a=document.createElement('a'); a.href=url;
    const extensions={audio:'wav',export:'md',transcript:'txt',summary:'md',metrics:'json'};
    a.download=`meeting-${id}-${kind}.${extensions[kind]}`; a.click(); setTimeout(()=>URL.revokeObjectURL(url),30000);
  }catch(e){notice(e.message);}
}
$('record-form').onsubmit=e=>{e.preventDefault(); action(async()=>{ if(!state) throw new Error('Noch keine Verbindung zum Gerät.'); $('record-button').disabled=true; $('record-button').setAttribute('aria-busy','true'); try {await api(state.recording.id?'/api/record/stop':'/api/record/start','POST',{title:$('title').value});} finally{$('record-button').disabled=false; $('record-button').removeAttribute('aria-busy');} });};
function showScreen(value) {
  $('keyboard').hidden=true;
  screen=value;
  $('screen-record').hidden=value!=='record';
  $('screen-meetings').hidden=value!=='meetings';
  $('settings').hidden=value!=='settings';
  const labels={record:'Aufnahme',meetings:'Meetings',settings:'Einstellungen'};
  $('page-label').textContent=labels[value];
  for(const [id,target] of [['nav-record','record'],['nav-meetings','meetings'],['settings-toggle','settings']]) {
    $(id).classList.toggle('active',value===target);
    if(value===target) $(id).setAttribute('aria-current','page');else $(id).removeAttribute('aria-current');
  }
  if(value==='settings') loadSetup();
  window.scrollTo(0,0);
}
$('settings-toggle').onclick=()=>showScreen('settings');
$('nav-record').onclick=()=>showScreen('record');
$('nav-meetings').onclick=()=>showScreen('meetings');
$('show-queue').onclick=()=>showScreen('meetings');
$('settings-form').onsubmit=e=>{e.preventDefault();action(async()=>{const config={};for(const input of e.target.elements){if(input.name)config[input.name]=input.type==='number'?Number(input.value):input.value;} await api('/api/settings','POST',config);});};
$('devices').onclick=()=>action(loadDevices);
$('close-detail').onclick=()=>{$('detail').close();selected=null;};
$('detail').addEventListener('close',()=>{selected=null;});
$('login-form').onsubmit=e=>{e.preventDefault();token=$('token').value;sessionStorage.setItem('meeting-token',token);$('token').value='';notice('');refresh();};
refresh(); setInterval(()=>{if(!busy)refresh();},3000);
setInterval(()=>{if(state?.recording.id)$('timer').textContent=formatDuration(Date.now()/1000-state.recording.started);},1000);

function showDetailTab(value) {
 for(const kind of ['summary','transcript','metrics']) {
  $(kind+'-area').hidden=kind!==value;
  $('tab-'+kind).setAttribute('aria-selected',kind===value?'true':'false');
 }
}
for(const kind of ['summary','transcript','metrics']) $('tab-'+kind).onclick=()=>showDetailTab(kind);

$('model-check').onclick=()=>action(loadSetup);
let keyboardTarget=null, keyboardShift=false;
document.addEventListener('focusin',e=>{if(e.target.tagName==='INPUT') keyboardTarget=e.target;});
function keyboardType(value) {
 const input=keyboardTarget;
 if(!input||input.disabled) {notice('Zuerst ein Eingabefeld auswählen.');return;}
 const start=input.selectionStart??input.value.length, end=input.selectionEnd??input.value.length;
 if(value==='BACK') {
   input.value=input.value.slice(0,Math.max(0,start-(start===end?1:0)))+input.value.slice(end);
   if(input.type!=='number') input.setSelectionRange(Math.max(0,start-1),Math.max(0,start-1));
 } else {
   input.value=input.value.slice(0,start)+value+input.value.slice(end);
   if(input.type!=='number') input.setSelectionRange(start+value.length,start+value.length);
 }
 input.dispatchEvent(new Event('input',{bubbles:true}));input.focus({preventScroll:true});
}
function buildKeyboard() {
 const container=$('keyboard-keys');container.replaceChildren();
 const rows=['1234567890/:.-','qwertzuiopü','asdfghjklöä','yxcvbnmß_@'];
 for(const row of rows) {
  const line=document.createElement('div');line.className='keyboard-row';
  for(const char of row)line.append(button(keyboardShift?char.toUpperCase():char,()=>keyboardType(keyboardShift?char.toUpperCase():char)));
  container.append(line);
 }
 const line=document.createElement('div');line.className='keyboard-row';
 line.append(button('⇧ Groß / klein',()=>{keyboardShift=!keyboardShift;buildKeyboard();}),button('Leertaste',()=>keyboardType(' ')),button('⌫ Löschen',()=>keyboardType('BACK')));
 container.append(line);
 for(const key of container.querySelectorAll('button'))key.addEventListener('pointerdown',e=>e.preventDefault());
}
$('keyboard-toggle').onclick=()=>{$('keyboard').hidden=!$('keyboard').hidden;};
$('keyboard-close').onclick=()=>{$('keyboard').hidden=true;};
buildKeyboard();

function setupStep(value) {
 setupTab=value;
 for(const tab of ['audio','models','ready']) { $('setup-'+tab).hidden=tab!==value;$('step-'+tab).classList.toggle('selected',tab===value); }
 if(value==='ready') loadSetup();
}
for(const tab of ['audio','models','ready']) $('step-'+tab).onclick=()=>setupStep(tab);
$('next-models').onclick=()=>setupStep('models');
$('next-ready').onclick=()=>setupStep('ready');
async function loadDevices() {
 const result=await api('/api/devices'), select=$('microphone-select');select.replaceChildren();
 if(!result.devices?.length) {const o=document.createElement('option');o.value='';o.textContent='Kein Mikrofon gefunden';select.append(o);select.disabled=true;$('audio-device-note').textContent=result.text||'Bitte ein USB-Mikrofon anschließen und aktualisieren.';return;}
 select.disabled=false;
 for(const d of result.devices){const o=document.createElement('option');o.value=d.id;o.textContent=d.label;select.append(o);}
 select.value=state.config.device;
 if(!select.value){const o=document.createElement('option');o.value=state.config.device;o.textContent='Bisherige Auswahl · momentan nicht gefunden';select.append(o);select.value=state.config.device;}
 $('audio-device-note').textContent=state.demo?'Demogeräte · keine echte Hardwareerkennung.':'Die Auswahl wird automatisch gespeichert.';
}
function fillModelSelect(select,items,current,field) {
 select.replaceChildren();
 for(const model of items){const o=document.createElement('option');o.value=model[field];o.textContent=model.label+' · '+(model.installed?'installiert':'noch herunterladen');select.append(o);}
 select.value=current;
 if(!select.value&&current){const o=document.createElement('option');o.value=current;o.textContent='Bisherige Auswahl · noch nicht verfügbar';select.append(o);select.value=current;}
}
function selectedModel(type) {
 if(!setupData)return null;
 return type==='whisper'?setupData.catalog.asr.find(m=>m.path===$('whisper-select').value):setupData.catalog.llm.find(m=>m.id===$('llm-select').value);
}
function modelDescriptions() {
 for(const [type,prefix] of [['whisper','whisper'],['ollama','llm']]){
  const m=selectedModel(type);if(!m)continue;
  $(prefix+'-description').textContent=m.description;
  $(prefix+'-license').textContent=m.license;
  const b=$('install-'+prefix);b.textContent=m.installed?'Bereits installiert':'Bewusst herunterladen';
  b.disabled=!!m.installed||state?.installation?.state==='running'||m.id==='custom';
 }
}
async function loadSetup() {
 try {setupData=await api('/api/setup');fillModelSelect($('whisper-select'),setupData.catalog.asr,setupData.catalog.selected_asr,'path');fillModelSelect($('llm-select'),setupData.catalog.llm,setupData.catalog.selected_llm,'id');modelDescriptions();
 const checks=$('readiness-checks');checks.replaceChildren();
 for(const check of setupData.checks){const row=document.createElement('div');row.className='readiness-row '+(check.ok?'ok':'missing');const status=document.createElement('strong');status.textContent=check.ok?'Bereit':'Offen';const label=document.createElement('span');label.textContent=check.label;row.append(label,status);checks.append(row);}
 $('finish-setup').disabled=!setupData.ready;
 $('runtime-note').textContent=!setupData.catalog.whisper_runtime||!setupData.catalog.ollama?'Ein Teil des Basissystems fehlt. Bitte die einmalige Geräteinstallation abschließen. Deine Modellwahl bleibt gespeichert.':'Downloads starten nur nach deinem Klick und benötigen Internet. Danach läuft die Verarbeitung lokal.';
 await loadDevices();
 }catch(e){notice(e.message);}
}
$('microphone-select').onchange=()=>action(async()=>{await api('/api/settings','POST',{device:$('microphone-select').value,setup_complete:false});$('audio-device-note').textContent='Mikrofon gespeichert. Bitte testen.';});
$('whisper-select').onchange=()=>action(async()=>{modelDescriptions();await api('/api/settings','POST',{whisper_model:$('whisper-select').value,setup_complete:false});});
$('llm-select').onchange=()=>action(async()=>{modelDescriptions();await api('/api/settings','POST',{summary_model:$('llm-select').value,setup_complete:false});});
for(const [type,prefix] of [['whisper','whisper'],['ollama','llm']]) $('install-'+prefix).onclick=()=>action(async()=>{
 const m=selectedModel(type);if(!m)throw new Error('Bitte zuerst ein Modell wählen.');
 if(!confirm(`${m.label} jetzt herunterladen? Dafür werden ungefähr ${(m.bytes/1e9).toFixed(1)} GB plus Reserve benötigt. ${m.license}. Es werden keine Meetingdaten übertragen.`))return;
 await api('/api/models/install','POST',{backend:type,model:m.id});
});
$('probe-start').onclick=()=>action(async()=>{await api('/api/microphone/test','POST',{});lastProbeState='';});
$('finish-setup').onclick=()=>action(async()=>{await api('/api/setup/complete','POST',{});showScreen('record');});
function renderSetupStatus() {
 const p=state.microphone_test||{state:'idle',level:0};
 $('probe-message').textContent=p.message||'Fünf Sekunden aufnehmen und danach anhören.';
 $('probe-level').value=p.level||0;
 $('probe-start').disabled=p.state==='running'||!!state.recording.id;
 $('probe-start').textContent=p.state==='running'?'Test läuft …':'Mikrofon testen';
 if(p.state==='completed'&&lastProbeState!=='completed'&&!state.demo) {
  fetch('/api/microphone/audio',{headers:{Authorization:token?'Bearer '+token:''}}).then(r=>{if(!r.ok)throw new Error();return r.blob();}).then(blob=>{if(audioURL)URL.revokeObjectURL(audioURL);audioURL=URL.createObjectURL(blob);$('probe-playback').src=audioURL;$('probe-playback').hidden=false;}).catch(()=>{});
 }
 lastProbeState=p.state;
 const d=state.installation||{state:'idle'};
 $('download-status').hidden=d.state==='idle';
 $('download-message').textContent=d.message||'';
 if(d.total>0){$('download-progress').value=Math.min(100,d.completed/d.total*100);}else $('download-progress').removeAttribute('value');
 $('download-detail').textContent=d.total>0?`${(d.completed/1e6).toFixed(1)} / ${(d.total/1e6).toFixed(1)} MB · aktueller Downloadabschnitt`:'Fortschritt wird vom lokalen Modelldienst gemeldet.';
 if(d.state!==lastDownloadState&&['completed','failed'].includes(d.state)&&screen==='settings')loadSetup();
 lastDownloadState=d.state;
 if(setupData)modelDescriptions();
}
