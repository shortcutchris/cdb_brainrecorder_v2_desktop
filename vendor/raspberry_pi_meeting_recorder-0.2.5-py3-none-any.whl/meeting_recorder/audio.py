"""ALSA recorder: raw PCM survives missing WAV headers after a crash."""
import os
from pathlib import Path
import shutil
import signal
import subprocess
import threading
import time
import wave
from .child_process import owned_command
from .core import now, sync_dir

RATE = 16000
BYTES_PER_SECOND = RATE * 2


def finalize(folder):
    folder = Path(folder)
    raw, wav = folder / 'audio.pcm', folder / 'audio.wav'
    if wav.exists():
        with wave.open(str(wav), 'rb') as f:
            if f.getnframes() == 0:
                raise RuntimeError('Die Aufnahme enthält keine Audiodaten.')
            return f.getnframes() / f.getframerate()
    if not raw.exists() or raw.stat().st_size < 2:
        raise RuntimeError('Keine Audiodaten vorhanden. Mikrofon und ALSA-Gerät prüfen.')
    size = raw.stat().st_size // 2 * 2
    tmp = folder / 'audio.wav.tmp'
    with open(raw, 'rb') as source, open(tmp, 'wb') as target:
        with wave.open(target, 'wb') as out:
            out.setnchannels(1)
            out.setsampwidth(2)
            out.setframerate(RATE)
            remaining = size
            while remaining:
                block = source.read(min(1024 * 1024, remaining))
                if not block:
                    raise RuntimeError('Audiodatei wurde unerwartet verkürzt.')
                out.writeframesraw(block)
                remaining -= len(block)
        target.flush()
        os.fsync(target.fileno())
    os.replace(tmp, wav)
    sync_dir(folder)
    raw.unlink()
    sync_dir(folder)
    return size / BYTES_PER_SECOND


def devices():
    if not shutil.which('arecord'):
        return {'available': False, 'devices': [], 'text': 'Der Mikrofontreiber fehlt. Basissysteminstallation abschließen.'}
    result = subprocess.run(['arecord', '-L'], capture_output=True, text=True, encoding='utf-8', errors='replace',
                            env=os.environ | {'LC_ALL':'C.UTF-8'}, timeout=10)
    entries = []
    for line in result.stdout.splitlines():
        if line and not line[0].isspace():
            if line == 'default' or line.startswith(('plughw:CARD=', 'sysdefault:CARD=')):
                entries.append({'id': line, 'label': line, 'description': ''})
            else:
                entries.append({'id': '', 'label': '', 'description': ''})
        elif entries and entries[-1]['id']:
            entries[-1]['description'] += ' ' + line.strip()
    valid = [e for e in entries if e['id']]
    if valid and all(e['id'] == 'default' for e in valid):
        capture = subprocess.run(['arecord', '-l'], capture_output=True, text=True, encoding='utf-8', errors='replace',
                            env=os.environ | {'LC_ALL':'C.UTF-8'}, timeout=10)
        if not any(line.lstrip().startswith(('card ', 'Karte ')) for line in capture.stdout.splitlines()):
            return {'available': False, 'devices': [], 'text': 'Kein Hardware-Mikrofon gefunden. Bitte USB-Mikrofon anschließen und aktualisieren.'}
    for entry in valid:
        if entry['id'] == 'default':
            entry['label'] = 'Standardmikrofon des Geräts'
        else:
            entry['label'] = entry['description'].strip() or entry['id']
    return {'available': result.returncode == 0 and bool(valid), 'devices': valid,
            'text': result.stdout or result.stderr or 'Kein Mikrofon gefunden. Bitte per USB anschließen und aktualisieren.'}


class Recorder:
    def __init__(self, store, command_factory=None):
        self.store = store
        self.command_factory = command_factory or self.command
        self.lock = threading.RLock()
        self.active = None
        self.probe = False
        self.proc = None
        self.output = self.log = None
        self.started = 0
        self.closed = threading.Event()

    @staticmethod
    def command(config):
        return ['arecord', '-q', '-D', config['device'], '-t', 'raw', '-f', 'S16_LE', '-r', str(RATE), '-c', '1']

    def recover(self):
        for job in self.store.list():
            if job['state'] == 'recording':
                try:
                    duration = finalize(self.store.folder(job['id']))
                    self.store.update(job['id'], state='queued', duration=duration, interrupted=1,
                                      error='Aufnahme beim Neustart wiederhergestellt; Ende möglicherweise unvollständig.')
                except Exception as e:
                    self.store.update(job['id'], state='failed', interrupted=1, error=str(e))

    def start(self, title=''):
        with self.lock:
            if self.active or self.probe:
                raise ValueError('Es läuft bereits eine Aufnahme.')
            config = self.store.config()
            if self.store.free_mb() < config['min_free_mb']:
                raise ValueError('Zu wenig freier Speicher für eine neue Aufnahme.')
            ident = self.store.create(title)
            folder = self.store.folder(ident)
            self.output = self.log = None
            try:
                self.output = open(folder / 'audio.pcm', 'wb', buffering=0)
                self.log = open(folder / 'recording.log', 'ab', buffering=0)
                self.proc = subprocess.Popen(owned_command(self.command_factory(config)), stdout=self.output, stderr=self.log,
                                             start_new_session=True)
            except Exception as e:
                if self.output: self.output.close()
                if self.log: self.log.close()
                self.store.update(ident, state='failed', error=f'Aufnahme konnte nicht starten: {e}')
                raise ValueError(f'Aufnahme konnte nicht starten: {e}') from e
            self.active, self.started = ident, now()
            self.last_sync = time.monotonic()
            self.limit = config['max_record_seconds']
            self.minimum = config['min_free_mb']
            return ident

    def status(self):
        with self.lock:
            return {'id': self.active, 'started': self.started if self.active else None,
                    'seconds': round(now() - self.started) if self.active else 0}

    def stop(self, reason=''):
        with self.lock:
            if not self.active:
                raise ValueError('Keine laufende Aufnahme.')
            ident, proc = self.active, self.proc
            unexpected = proc.poll() is not None
            write_error = None
            try:
                if proc.poll() is None:
                    os.killpg(proc.pid, signal.SIGINT)
                    try:
                        proc.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL)
                        proc.wait(timeout=5)
                        reason = reason or 'Aufnahmeprozess musste beendet werden; Audio prüfen.'
                os.fsync(self.output.fileno())
            except OSError as e:
                write_error = e
            finally:
                self.output.close()
                self.log.close()
                self.active = self.proc = None
            if write_error:
                message = 'Aufnahme konnte nicht synchronisiert werden. Datenträger prüfen; PCM bleibt erhalten.'
                self.store.update(ident, state='failed', interrupted=1, error=message)
                raise ValueError(message) from write_error
            try:
                duration = finalize(self.store.folder(ident))
                warning = reason or ('Mikrofonprozess unerwartet beendet; Audio prüfen.' if unexpected else '')
                self.store.update(ident, state='queued', duration=duration, interrupted=int(bool(warning)), error=warning)
            except Exception as e:
                self.store.update(ident, state='failed', error=str(e), interrupted=1)
                raise ValueError(str(e)) from e
            return ident

    def monitor(self):
        while not self.closed.wait(1):
            with self.lock:
                if not self.active:
                    continue
                reason = ''
                if self.proc.poll() is not None:
                    reason = 'Mikrofonprozess unerwartet beendet; Audio prüfen.'
                elif now() - self.started >= self.limit:
                    reason = 'Maximale Aufnahmedauer erreicht; Aufnahme automatisch beendet.'
                elif self.store.free_mb() < max(self.minimum // 2, (self.store.folder(self.active) / 'audio.pcm').stat().st_size // (1024 * 1024) + 128):
                    reason = 'Speicher wird knapp; Aufnahme automatisch beendet.'
                if time.monotonic() - self.last_sync >= 5:
                    try:
                        os.fsync(self.output.fileno())
                        self.last_sync = time.monotonic()
                    except OSError:
                        reason = "Audiodaten konnten nicht dauerhaft gespeichert werden; Datenträger prüfen."
                if reason:
                    try:
                        self.stop(reason)
                    except Exception:
                        pass  # The job retains its error; monitor remains alive.

    def close(self):
        self.closed.set()
        with self.lock:
            if self.active:
                self.stop('Dienst beendet; laufende Aufnahme wurde gesichert.')
