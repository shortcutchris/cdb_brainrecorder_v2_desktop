"""Loopback-first web application, authentication and CSRF protection."""
import argparse
import fcntl
import hmac
import json
import logging
import os
from pathlib import Path
import secrets
import shutil
import signal
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
from .audio import Recorder, devices
from .core import Store
from .processing import Worker
from .setup import ModelManager
from .probe import MicrophoneTest

STATIC = Path(__file__).parent / 'static'


class App:
    def __init__(self, root, token='', recorder_factory=Recorder, backend=None):
        self.token = token
        self.csrf = secrets.token_urlsafe(32)
        root = Path(root).expanduser()
        root.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.lock = open(root / 'service.lock', 'a')
        try:
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.lock.close()
            raise RuntimeError('Ein Recorder-Dienst verwendet dieses Datenverzeichnis bereits.')
        self.store = Store(root)
        self.recorder = recorder_factory(self.store)
        self.worker = Worker(self.store, backend)
        self.models = ModelManager(self.store)
        self.probe = MicrophoneTest(self.recorder)
        self.recorder.recover()
        self.store.recover_processing()
        for job in self.store.list():
            if job['state'] == 'deleting':
                self.delete(job['id'])
        self.threads = []

    def start(self):
        for target in (self.recorder.monitor, self.worker.run):
            t = threading.Thread(target=target, daemon=True)
            t.start()
            self.threads.append(t)

    def close(self):
        self.worker.stopping.set()
        self.models.close()
        self.probe.close()
        try:
            self.recorder.close()
        except Exception:
            logging.exception('Laufende Aufnahme konnte beim Beenden nicht finalisiert werden')
        for t in self.threads:
            t.join(timeout=6)
        # If an HTTP generation is still in flight, exit releases the lock. Do not
        # explicitly unlock while that worker might still touch the database.

    def delete(self, ident):
        with self.store.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT state FROM jobs WHERE id=?', (ident,)).fetchone()
            if not row:
                raise KeyError('Meeting nicht gefunden.')
            if row[0] in ('recording', 'transcribing', 'summarizing'):
                raise ValueError('Laufende Aufnahme/Verarbeitung kann nicht gelöscht werden.')
            db.execute("UPDATE jobs SET state='deleting' WHERE id=?", (ident,))
        shutil.rmtree(self.store.folder(ident), ignore_errors=False) if self.store.folder(ident).exists() else None
        with self.store.db() as db:
            db.execute('DELETE FROM jobs WHERE id=?', (ident,))

    def audio_devices(self):
        return devices()

    def setup_state(self):
        catalog = self.models.catalog()
        c = self.store.config()
        probe = self.probe.status()
        checks = [
            {'label': 'Mikrofon getestet', 'ok': probe.get('state') == 'completed' and probe.get('device') == c['device']},
            {'label': 'Transkriptionsprogramm vorhanden', 'ok': catalog['whisper_runtime']},
            {'label': 'Sprachmodell installiert', 'ok': any(m['path'] == c['whisper_model'] and m['installed'] for m in catalog['asr'])},
            {'label': 'Lokaler Modelldienst bereit', 'ok': catalog['ollama']},
            {'label': 'Zusammenfassungsmodell installiert', 'ok': any(m['id'] == c['summary_model'] and m['installed'] for m in catalog['llm'])},
        ]
        return {'catalog': catalog, 'checks': checks, 'ready': all(c['ok'] for c in checks), 'probe': probe}

    def state(self):
        jobs = self.store.list()
        return {'jobs': jobs, 'recording': self.recorder.status(), 'config': self.store.config(),
                'installation': self.models.status(), 'microphone_test': self.probe.status(),
                'needs_setup': not self.store.config()['setup_complete'],
                'progress': self.worker.progress, 'free_mb': self.store.free_mb(), 'csrf': self.csrf,
                'data_dir': str(self.store.root), 'platform_note': 'Aufnahme erfolgt am Mikrofon dieses Geräts (ALSA), nicht im Browser.'}


class Server(ThreadingHTTPServer):
    daemon_threads = True
    def get_request(self):
        connection, address = super().get_request()
        connection.settimeout(15)
        return connection, address

    def __init__(self, address, app):
        self.app = app
        super().__init__(address, Handler)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Do not log query strings, titles, transcript data or authorization.
        logging.info('%s %s', self.command, self.path.split('?')[0])

    def headers_base(self, mime, length):
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(length))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; media-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")

    def respond(self, value, status=200):
        body = json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status)
        self.headers_base('application/json; charset=utf-8', len(body))
        self.end_headers()
        self.wfile.write(body)

    def authorized(self):
        host = self.headers.get('Host', '')
        parsed = urlsplit('http://' + host)
        # Prevent DNS rebinding when serving only loopback.
        if self.server.server_address[0] == '127.0.0.1' and parsed.hostname not in ('127.0.0.1', 'localhost'):
            self.respond({'error': 'Host nicht erlaubt.'}, 403)
            return False
        token = self.server.app.token
        if token and not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + token):
            self.respond({'error': 'Zugriffstoken erforderlich.'}, 401)
            return False
        return True

    def do_GET(self):
        try:
            self.get()
        except (BrokenPipeError, ConnectionResetError):
            pass
        except (ValueError, KeyError) as e:
            self.respond({'error': str(e)}, 404)
        except Exception:
            logging.exception('GET fehlgeschlagen')
            self.respond({'error': 'Interner Fehler. Dienstprotokoll prüfen.'}, 500)

    def get(self):
        path = urlsplit(self.path).path
        if path == '/favicon.ico':
            self.send_response(204)
            self.end_headers()
            return
        if path.startswith('/icons/'):
            name = path.removeprefix('/icons/')
            if '/' in name or not name.endswith('.svg') or not (STATIC / 'icons' / name).is_file():
                raise KeyError('Symbol nicht gefunden.')
            body = (STATIC / 'icons' / name).read_bytes()
            self.send_response(200)
            self.headers_base('image/svg+xml', len(body))
            self.end_headers()
            self.wfile.write(body)
            return
        if path in ('/', '/app.js', '/style.css'):
            filename = {'/': 'index.html', '/app.js': 'app.js', '/style.css': 'style.css'}[path]
            body = (STATIC / filename).read_bytes()
            mime = {'/': 'text/html', '/app.js': 'text/javascript', '/style.css': 'text/css'}[path]
            self.send_response(200)
            self.headers_base(mime + '; charset=utf-8', len(body))
            self.end_headers()
            self.wfile.write(body)
            return
        if not self.authorized():
            return
        app = self.server.app
        if path == '/api/state':
            self.respond(app.state())
        elif path == '/api/diagnostics':
            c = app.store.config()
            result = {'whisper_binary': Path(c['whisper_binary']).is_file() and os.access(c['whisper_binary'], os.X_OK),
                      'whisper_model': Path(c['whisper_model']).is_file(), 'ollama': False, 'models': []}
            try:
                opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
                with opener.open('http://127.0.0.1:11434/api/tags', timeout=3) as response:
                    result['models'] = [m['name'] for m in json.load(response).get('models', [])]
                result['ollama'] = True
            except (OSError, ValueError):
                pass
            self.respond(result)
        elif path == '/api/devices':
            self.respond(app.audio_devices())
        elif path == '/api/setup':
            self.respond(app.setup_state())
        elif path == '/api/microphone/audio':
            f = app.probe.folder / 'audio.wav'
            if not f.is_file():
                raise KeyError('Noch keine Testaufnahme vorhanden.')
            body = f.read_bytes()
            self.send_response(200)
            self.headers_base('audio/wav', len(body))
            self.end_headers()
            self.wfile.write(body)
        elif path.startswith('/api/meetings/'):
            parts = path.strip('/').split('/')
            if len(parts) not in (3, 4):
                raise KeyError('Nicht gefunden.')
            ident = parts[2]
            job = app.store.get(ident)
            folder = app.store.folder(ident)
            if len(parts) == 3:
                for key, filename in [('transcript', 'transcript.txt'), ('summary', 'summary.md')]:
                    f = folder / filename
                    job[key] = f.read_text(encoding='utf-8') if f.exists() else ''
                self.respond(job)
            else:
                kind = parts[3]
                mapping = {'audio': ('audio.wav', 'audio/wav'), 'transcript': ('transcript.txt', 'text/plain; charset=utf-8'),
                           'summary': ('summary.md', 'text/markdown; charset=utf-8'), 'metrics': ('metrics.json', 'application/json')}
                if kind == 'export':
                    text = f"# {job['title']}\n\n"
                    for title, name in [('Zusammenfassung', 'summary.md'), ('Transkript', 'transcript.txt')]:
                        f = folder / name
                        text += f'## {title}\n\n' + (f.read_text(encoding='utf-8') if f.exists() else 'Noch nicht verfügbar.') + '\n\n'
                    payload = text.encode()
                    self.send_response(200)
                    self.headers_base('text/markdown; charset=utf-8', len(payload))
                    self.send_header('Content-Disposition', f'attachment; filename="meeting-{ident}.md"')
                    self.end_headers()
                    self.wfile.write(payload)
                    return
                if kind not in mapping:
                    raise KeyError('Unbekannter Export.')
                name, mime = mapping[kind]
                f = folder / name
                if not f.exists():
                    raise KeyError('Datei noch nicht verfügbar.')
                with open(f, 'rb') as stream:
                    self.send_response(200)
                    self.headers_base(mime, f.stat().st_size)
                    self.send_header('Content-Disposition', f'attachment; filename="{ident}-{name}"')
                    self.end_headers()
                    shutil.copyfileobj(stream, self.wfile)
        else:
            raise KeyError('Nicht gefunden.')

    def do_POST(self):
        try:
            if not self.authorized():
                return
            app = self.server.app
            origin = self.headers.get('Origin')
            if origin and origin != 'http://' + self.headers.get('Host', ''):
                self.respond({'error': 'Fremder Ursprung nicht erlaubt.'}, 403)
                return
            if not hmac.compare_digest(self.headers.get('X-CSRF-Token', ''), app.csrf):
                self.respond({'error': 'Sitzung ungültig. Seite neu laden.'}, 403)
                return
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 <= length <= 16384:
                self.respond({'error': 'Anfrage zu groß.'}, 413)
                return
            body = json.loads(self.rfile.read(length) or b'{}')
            if not isinstance(body, dict):
                raise ValueError('JSON-Objekt erwartet.')
            path = urlsplit(self.path).path
            if path == '/api/record/start':
                if not app.store.config()['setup_complete']:
                    raise ValueError('Bitte zuerst die kurze Einrichtung abschließen.')
                self.respond({'id': app.recorder.start(body.get('title', ''))})
            elif path == '/api/record/stop':
                self.respond({'id': app.recorder.stop()})
            elif path == '/api/models/install':
                self.respond(app.models.install(body.get('backend'), body.get('model')))
            elif path == '/api/microphone/test':
                self.respond(app.probe.start())
            elif path == '/api/setup/complete':
                if not app.setup_state()['ready']:
                    raise ValueError('Noch nicht bereit. Bitte die offenen Punkte in der Einrichtung prüfen.')
                app.store.save_config({'setup_complete': True})
                self.respond({'ok': True})
            elif path == '/api/settings':
                if app.recorder.status()['id'] or app.recorder.probe:
                    raise ValueError('Einstellungen erst nach Aufnahmeende ändern.')
                self.respond({'config': app.store.save_config(body)})
            elif path.startswith('/api/meetings/'):
                parts = path.strip('/').split('/')
                if len(parts) != 4:
                    raise KeyError('Nicht gefunden.')
                ident, action = parts[2:]
                app.store.get(ident)
                if action == 'retry':
                    app.store.retry(ident)
                elif action == 'delete':
                    app.delete(ident)
                else:
                    raise KeyError('Unbekannte Aktion.')
                self.respond({'ok': True})
            else:
                raise KeyError('Nicht gefunden.')
        except (BrokenPipeError, ConnectionResetError):
            pass
        except (ValueError, KeyError) as e:
            self.respond({'error': str(e)}, 400)
        except Exception:
            logging.exception('Aktion fehlgeschlagen')
            self.respond({'error': 'Aktion fehlgeschlagen. Dienstprotokoll und freien Speicher prüfen.'}, 500)


def main():
    parser = argparse.ArgumentParser(description='Lokaler Meetingraumrekorder')
    parser.add_argument('--data-dir', default=os.environ.get('MEETING_DATA_DIR', str(Path.home() / '.local/share/meeting-recorder')))
    parser.add_argument('--host', default=os.environ.get('MEETING_HOST', '127.0.0.1'))
    parser.add_argument('--port', type=int, default=int(os.environ.get('MEETING_PORT', '8080')))
    args = parser.parse_args()
    token = os.environ.get('MEETING_TOKEN', '')
    if args.host != '127.0.0.1' and len(token) < 24:
        parser.error('Netzwerkzugriff erfordert MEETING_TOKEN mit mindestens 24 Zeichen. SSH-Tunnel empfohlen.')
    os.umask(0o077)
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    app = App(args.data_dir, token)
    server = Server((args.host, args.port), app)
    server.timeout = 1
    app.start()
    stopping = threading.Event()
    def stop(*_):
        stopping.set()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    logging.info('Meeting Recorder bereit auf %s:%s', args.host, args.port)
    try:
        while not stopping.is_set():
            server.handle_request()
    finally:
        server.server_close()
        app.close()

if __name__ == '__main__':
    main()
