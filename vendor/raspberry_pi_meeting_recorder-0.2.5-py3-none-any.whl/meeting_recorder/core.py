"""Durable storage and configuration. No external Python dependencies."""
import contextlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import time
import uuid

DEFAULTS = {
    'device': 'default', 'whisper_binary': '/opt/meeting-recorder/whisper.cpp/build/bin/whisper-cli',
    'whisper_model': '/var/lib/meeting-recorder/models/ggml-medium.bin',
    'summary_model': 'qwen3:8b', 'threads': 3, 'chunk_chars': 6000,
    'process_timeout': 21600, 'summary_timeout': 1800, 'max_record_seconds': 21600,
    'min_free_mb': 1024, 'setup_complete': False,
}


def now():
    return time.time()


def atomic_write(path, content):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(content)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    sync_dir(path.parent)


def sync_dir(path):
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


class Store:
    def __init__(self, root):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.meetings = self.root / 'meetings'
        self.meetings.mkdir(mode=0o700, exist_ok=True)
        self.path = self.root / 'queue.sqlite3'
        with self.db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL, state TEXT NOT NULL,
                    created REAL NOT NULL, updated REAL NOT NULL, duration REAL DEFAULT 0,
                    error TEXT DEFAULT '', attempts INTEGER DEFAULT 0,
                    interrupted INTEGER DEFAULT 0, metrics TEXT DEFAULT '{}'
                );
                CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS jobs_queue ON jobs(state, created);
            ''')

        with self.db() as db:
            columns={row['name'] for row in db.execute('PRAGMA table_info(jobs)')}
            if 'queued_at' not in columns:
                db.execute('ALTER TABLE jobs ADD COLUMN queued_at REAL')
                db.execute("UPDATE jobs SET queued_at=created WHERE state IN ('queued','transcribing','summarizing')")

    @contextlib.contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA synchronous=FULL')
        try:
            with db:
                yield db
        finally:
            db.close()

    def config(self):
        with self.db() as db:
            row = db.execute('SELECT value FROM settings WHERE id=1').fetchone()
        defaults = DEFAULTS | {'whisper_model': str(self.root / 'models' / 'ggml-medium.bin')}
        return defaults | (json.loads(row[0]) if row else {})

    def save_config(self, changes):
        if not isinstance(changes, dict) or set(changes) - set(DEFAULTS):
            raise ValueError('Unbekannte Einstellung.')
        c = self.config() | changes
        if type(c['setup_complete']) is not bool:
            raise ValueError('Ungültiger Einrichtungsstatus.')
        for k in ('device', 'whisper_binary', 'whisper_model', 'summary_model'):
            if not isinstance(c[k], str) or not c[k].strip() or len(c[k]) > 512 or '\x00' in c[k] or '\n' in c[k]:
                raise ValueError(f'Ungültige Einstellung: {k}')
        if 'cloud' in c['summary_model'].lower():
            raise ValueError('Cloudmodelle sind für dieses lokale Gerät nicht erlaubt.')
        if c['device'].startswith('-'):
            raise ValueError('Ungültiges Audiogerät.')
        for k, lo, hi in [('threads', 1, 4), ('chunk_chars', 1000, 10000),
                          ('process_timeout', 30, 86400), ('summary_timeout', 10, 7200),
                          ('max_record_seconds', 10, 21600), ('min_free_mb', 100, 100000)]:
            if type(c[k]) is not int or not lo <= c[k] <= hi:
                raise ValueError(f'{k}: erwartet {lo} bis {hi}.')
        with self.db() as db:
            db.execute('INSERT OR REPLACE INTO settings VALUES (1, ?)', (json.dumps(c),))
        return c

    def create(self, title):
        title = str(title).strip()[:160] or time.strftime('Meeting %d.%m.%Y %H:%M')
        ident = uuid.uuid4().hex
        folder = self.meetings / ident
        folder.mkdir(mode=0o700)
        sync_dir(self.meetings)
        with self.db() as db:
            db.execute('INSERT INTO jobs(id,title,state,created,updated) VALUES(?,?,?,?,?)',
                       (ident, title, 'recording', now(), now()))
        return ident

    def folder(self, ident):
        if len(ident) != 32 or any(c not in '0123456789abcdef' for c in ident):
            raise ValueError('Ungültige Meeting-ID.')
        return self.meetings / ident

    def get(self, ident):
        self.folder(ident)
        with self.db() as db:
            row = db.execute('SELECT * FROM jobs WHERE id=?', (ident,)).fetchone()
        if not row:
            raise KeyError('Meeting nicht gefunden.')
        return dict(row)

    def list(self):
        with self.db() as db:
            return [dict(r) for r in db.execute('SELECT * FROM jobs ORDER BY created DESC')]

    def update(self, ident, **fields):
        allowed = {'state', 'duration', 'error', 'attempts', 'interrupted', 'metrics'}
        if not fields or set(fields) - allowed:
            raise ValueError('Ungültige Jobänderung.')
        fields['updated'] = now()
        with self.db() as db:
            if fields.get('state')=='queued':
                previous=db.execute('SELECT state,queued_at FROM jobs WHERE id=?',(ident,)).fetchone()
                if not previous or previous['state'] not in ('transcribing','summarizing') or previous['queued_at'] is None:
                    fields['queued_at']=now()
            db.execute('UPDATE jobs SET ' + ','.join(f'{k}=?' for k in fields) + ' WHERE id=?',
                       (*fields.values(), ident))

    def claim(self):
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute("SELECT * FROM jobs WHERE state='queued' ORDER BY COALESCE(queued_at,created), created LIMIT 1").fetchone()
            if row:
                db.execute("UPDATE jobs SET state='transcribing', attempts=attempts+1, error='', updated=? WHERE id=?",
                           (now(), row['id']))
                return dict(row)
        return None

    def recover_processing(self):
        with self.db() as db:
            db.execute("UPDATE jobs SET state='queued', updated=? WHERE state IN ('transcribing','summarizing')", (now(),))

    def retry(self, ident):
        with self.db() as db:
            changed = db.execute("UPDATE jobs SET state='queued', error='', updated=?, queued_at=? WHERE id=? AND state='failed'",
                                 (now(), now(), ident)).rowcount
        if not changed:
            raise ValueError('Nur fehlgeschlagene Meetings können wiederholt werden.')

    def free_mb(self):
        return shutil.disk_usage(self.root).free // (1024 * 1024)
