"""Linux exec trampoline: capture/inference children cannot outlive their owner.

A separate interpreter avoids unsafe preexec_fn hooks in a multithreaded Qt app.
The parent-PID check closes the race between spawn and prctl registration.
"""
import ctypes
import os
import signal
import sys


def owned_command(command):
    if sys.platform != 'linux':return command
    return [sys.executable,'-m','meeting_recorder.child_process',str(os.getpid()),*command]


def main():
    parent=int(sys.argv[1]);command=sys.argv[2:]
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(1,signal.SIGTERM,0,0,0)!=0:
        raise OSError(ctypes.get_errno(),'Cannot register parent-death signal')
    if os.getppid()!=parent:return
    os.execvp(command[0],command)


if __name__=='__main__':main()
