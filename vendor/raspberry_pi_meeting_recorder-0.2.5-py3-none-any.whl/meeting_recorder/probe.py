"""Five-second microphone test on the Pi, independent of browser microphones."""
from array import array
import json
import math
import os
import signal
import subprocess
import sys
import threading
import time
from .audio import finalize
from .child_process import owned_command
from .core import atomic_write


class MicrophoneTest:
    def __init__(self, recorder):
        self.recorder = recorder
        self.store = recorder.store
        self.folder = self.store.root / 'microphone-test'
        self.folder.mkdir(mode=0o700, exist_ok=True)
        self.result = {'state': 'idle', 'message': 'Noch kein Mikrofontest durchgeführt.', 'level': 0}
        saved = self.folder / 'result.json'
        if saved.exists():
            try:
                self.result = json.loads(saved.read_text())
            except (OSError, ValueError):
                pass
        if self.result.get('state') == 'running':
            self.result = {'state': 'failed', 'message': 'Letzter Mikrofontest wurde unterbrochen. Bitte wiederholen.', 'level': 0}
        self.thread = None
        self.proc = None
        self.stopping = threading.Event()
        self.lock = threading.Lock()

    def status(self):
        with self.lock:
            return dict(self.result)

    def update(self, **fields):
        with self.lock:
            self.result.update(fields)

    def start(self):
        with self.recorder.lock:
            if self.recorder.active or self.recorder.probe:
                raise ValueError('Bitte die laufende Aufnahme oder den Mikrofontest zuerst beenden.')
            if self.store.free_mb() < 128:
                raise ValueError('Zu wenig freier Speicher für den Mikrofontest.')
            self.recorder.probe = True
            self.update(state='running', message='Sprich jetzt fünf Sekunden in das Mikrofon.', level=0)
            atomic_write(self.folder/'result.json', json.dumps(self.status(), ensure_ascii=False))
            self.thread = threading.Thread(target=self.run, daemon=True)
            self.thread.start()
        return self.status()

    @staticmethod
    def level(raw):
        samples = array('h', raw[:len(raw)//2*2])
        if not samples:
            return 0
        if sys.byteorder != 'little':
            samples.byteswap()
        rms = math.sqrt(sum(s*s for s in samples) / len(samples)) / 32768
        db = 20 * math.log10(max(rms, 1e-5))
        return round(max(0, min(100, (db + 60) / 60 * 100)))

    def run(self):
        raw = self.folder / 'audio.pcm'
        maximum = 0
        config = self.store.config()
        try:
            (self.folder / 'audio.wav').unlink(missing_ok=True)
            with open(raw, 'wb', buffering=0) as output, open(self.folder/'recording.log', 'wb') as log:
                cmd = self.recorder.command_factory(config) + ['-d', '5']
                self.proc = subprocess.Popen(owned_command(cmd), stdout=output, stderr=log, start_new_session=True)
                started = time.monotonic()
                while self.proc.poll() is None:
                    if self.stopping.wait(.2) or time.monotonic()-started > 10:
                        os.killpg(self.proc.pid, signal.SIGTERM)
                        raise RuntimeError('Mikrofontest wurde unterbrochen.')
                    with open(raw, 'rb') as sample:
                        sample.seek(max(0, raw.stat().st_size-32000))
                        level = self.level(sample.read())
                    maximum = max(maximum, level)
                    self.update(level=level)
                if self.proc.returncode:
                    raise RuntimeError('Mikrofon konnte nicht aufgenommen werden. Anderes Gerät wählen und USB-Verbindung prüfen.')
                os.fsync(output.fileno())
            duration = finalize(self.folder)
            if duration < .2:
                raise RuntimeError('Keine ausreichende Testaufnahme vorhanden.')
            self.update(state='completed', level=maximum, device=config['device'],
                        message='Testaufnahme bereit. Bitte anhören.' if maximum > 5 else 'Sehr leise Aufnahme. Mikrofon prüfen und Testaufnahme anhören.')
            atomic_write(self.folder/'result.json', json.dumps(self.status(), ensure_ascii=False))
        except Exception as e:
            self.update(state='failed', message=str(e)[:300])
            try:
                atomic_write(self.folder/'result.json', json.dumps(self.status(), ensure_ascii=False))
            except OSError:
                pass
        finally:
            if self.proc and self.proc.poll() is None:
                os.killpg(self.proc.pid, signal.SIGKILL)
                self.proc.wait()
            self.proc = None
            with self.recorder.lock:
                self.recorder.probe = False

    def close(self):
        self.stopping.set()
