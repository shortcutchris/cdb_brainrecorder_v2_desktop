"""Linux process RSS sampling. Measurements are observations, not guarantees."""
from pathlib import Path
import threading


def ollama_rss_kib(proc_root=Path('/proc')):
    total=0
    for p in proc_root.iterdir():
        if not p.name.isdigit():continue
        try:
            comm=(p/'comm').read_text().strip()
            executable=(p/'cmdline').read_bytes().split(b'\0',1)[0].decode(errors='replace')
            # Current CPU runners are named llama-server, inside Ollama's lib dir.
            if 'ollama' in comm or 'ollama' in Path(executable).parts:
                total+=next((int(x.split()[1]) for x in (p/'status').read_text().splitlines() if x.startswith('VmRSS:')),0)
        except (OSError,ValueError):pass
    return total


class ResourceSample:
    def __init__(self):
        self.done=threading.Event();self.minimum_available=None;self.ollama_peak=0
        self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()

    def run(self):
        while not self.done.is_set():
            try:
                available=next(int(x.split()[1]) for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
                self.minimum_available=min(self.minimum_available or available,available)
                self.ollama_peak=max(ollama_rss_kib(),self.ollama_peak)
            except (OSError,ValueError,StopIteration):pass
            self.done.wait(.5)

    def finish(self):
        self.done.set();self.thread.join(1)
        result={}
        if self.minimum_available is not None:result['system_min_available_mib']=round(self.minimum_available/1024,1)
        if self.ollama_peak:result['ollama_aggregate_peak_rss_mib']=round(self.ollama_peak/1024,1)
        return result
