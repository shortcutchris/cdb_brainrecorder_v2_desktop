"""Convert a named PipeWire/PulseAudio source to the recorder's mono PCM format."""
import argparse
import os


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', required=True)
    parser.add_argument('-d', type=int, default=0)
    args = parser.parse_args()
    command = ['ffmpeg', '-nostdin', '-v', 'error', '-f', 'pulse', '-i', args.device]
    if args.d:
        command += ['-t', str(args.d)]
    command += ['-ac', '1', '-ar', '16000', '-f', 's16le', 'pipe:1']
    os.execvp(command[0], command)


if __name__ == '__main__':
    main()
